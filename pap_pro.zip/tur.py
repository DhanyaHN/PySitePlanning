import turtle
def draw(D):
	l=[]
	for i in D.keys():
		for j in D[i].keys():
			for k in D[i][j].keys():
				n=D[i][j][k]
				l.append(n)
				#float(n)
                                #print(n)
				#y=100
				turtle.setx(int(n))
		         	#turtle.position() 
	turtle.mainloop()  

