#file reading
import turtle, tkinter, math

f = open("file1.txt","r")
f = f.readlines() # reading file into a variable
dim = f[0].split(":")[1] # stores the site dimension
D = {} # Dictionary containing site plan
print("dimension is ",dim)
# strips next line in all the lines
for i in range(0,len(f)):
	f[i] = f[i].strip()

# to create a dictionary of site plan
for i in range(1,len(f)):
	global floor
	global rooms
	if f[i].find("-") < 0 and len(f[i]) > 0:# if it is not "--------" and empty line
		if f[i].find(",") < 0: # it is the floor/partition
			if flag == True: # it is a floor
				floor = f[i].strip()
				D[floor] = {}
			else: # it is a room
				rooms = f[i].strip()
				D[floor][rooms] = {}
		else: # it is the dimensions of the room
			f[i].strip()
			l = f[i].split(",")
			for j in l:
				a = j.split(":")
				D[floor][rooms][a[0].strip()] = int(a[1])
		flag = False		
	elif len(f[i]) != 0:# if "---------------" is found then next line is the floor
		flag = True	

print(D)
#change of plan
print("Site dimension is ", dim)
change=input("Do you want to change it [Y or n]")
if(change=='Y'):
	length=int(input("Enter length"))
	breadth=int(input("Enter breadth")) 	#new dimensions
	k,l=dim.split('*')
	k,l=int(k),int(l)
	l_rate=length/k
	b_rate=breadth/l
	for i in D:
		print(i)
		for j in D[i]:
			print(j)
			D[i][j]['length']*=l_rate
			D[i][j]['width']*=b_rate
			D[i][j]['left']*=b_rate
			D[i][j]['top']*=l_rate
	print(D)
	dim=str(str(length)+'*'+str(breadth))
	print(dim)
else:
	print("site dimension is ",dim)
root = []
d = dim.split("*")
def check(flag, init_x, init_y, rooms, l):
	checked = []
	for i in rooms:
		for j in rooms:
			if i != j:
				x1 = (rooms[i]["left"] - init_x, rooms[i]["left"]+rooms[i]["width"] - init_x)
				y1 = (init_y - rooms[i]["top"], init_y - rooms[i]["top"] - rooms[i]["length"])
				x2 = (rooms[j]["left"] - init_x, rooms[j]["left"] + rooms[j]["width"] - init_x)
				y2 = (init_y - rooms[j]["top"],init_y - rooms[j]["top"] - rooms[j]["length"])
				#print(i,": x1,y1",x1,y1)
				#print(j,": x2,y2",x2,y2)
				#print()
				if x1[0] < x1[1]:
					a = x1[0]
					b = x1[1]
				else:
					a = x1[1]
					b = x1[0]
				if y1[0] < y1[1]:
					c = y1[0]
					d = y1[1]
				else:
					c = y1[1]
					d = y1[0]
				x_cor = (a < x2[0] < b) or (a < x2[1] < b)
				y_cor = (c < y2[0] < d) or (c < y2[1] < d)
				if (x_cor and y_cor) or (x_cor and (y1 == y2)) or (y_cor and (x1 == x2)):
					print(i,j)
					l.append((i,j))
					flag = True
				checked.append((i,j))
	return flag, l
def draw_door(t,door_dim):
	t.setx(door_dim['left'] + door_dim["width"] - init_x)
	t.sety(init_y - door_dim["top"])
	t.right(180)
	t.color("brown")
	t.forward(door_dim["length"]/3)
	t.pendown()
	t.right(90)
	t.forward(door_dim["width"]/4)
	t.left(90)
	t.forward(door_dim["length"]/3)
	t.left(90)
	t.forward(door_dim["width"]/4)

def right_arrow(t, tri):
	t.begin_fill()
	t.right(45)
	t.forward(tri)
	t.right(135)
	t.forward(10)
	t.right(135)
	t.forward(tri)
	t.right(45)
	t.end_fill()
def left_arrow(t,tri):
	t.begin_fill()
	t.forward(tri)
	t.left(135)
	t.forward(10)
	t.left(135)
	t.forward(tri)
	t.right(45)
	t.end_fill()
def up_arrow(t, tri):
	t.begin_fill()
	t.left(45)
	t.forward(tri)
	t.left(135)
	t.forward(10)
	t.left(135)
	t.forward(tri)
	t.left(45)
	t.end_fill()

def down_arrow(t, tri):
	t.begin_fill()
	t.left(135)
	t.forward(tri)
	t.left(135)
	t.forward(10)
	t.left(135)
	t.forward(tri)
	t.right(45)
	t.end_fill()

def write_dim(t, dim):
	t.pendown()
	t.speed(0)
	t.pensize(1)
	t.forward(20)
	t.backward(10)
	tri = 5 * math.sqrt(2) # calculates the side of a triangle(arrow)
	right_arrow(t, tri) # draws right arrow 
	t.right(90)
	t.forward(dim["width"]/2)
	t.color("red")
	t.write(str(dim["width"]),align = "center", font = ("Arial", 8, "bold"))
	t.color("blue")
	t.forward(dim["width"]/2 )
	t.left(135)
	left_arrow(t, tri) # draws left arrow
	t.left(90)
	t.forward(10)
	t.backward(20)
	t.left(90)
	t.penup()
	t.forward(dim["width"])
	t.pendown()
	t.forward(20)
	t.backward(10)
	up_arrow(t,tri)	# draws up arrow
	t.left(90)
	t.forward(dim["length"]/3)
	t.color("red")
	t.write(str(dim["length"]),align = "center", font = ("Arial", 8, "bold"))
	t.color("blue")
	t.forward(2 * dim["length"]/3)
	down_arrow(t,tri) # draws down arrow
	# steps to come back to its initial position
	t.right(90)
	t.forward(10)
	t.backward(20)
	t.right(90)
	t.penup()
	t.forward(dim["length"])
	t.pendown()
	t.pensize(2)

def draw_plan(m,init_x, init_y):
	root.append(tkinter.Tk())
	print(d[1])
	print(d[0])
	cv = tkinter.Canvas(root[m], width=int(d[1])+50,height=int(d[0])+50, bg="#ffeeee")
	a = tkinter.Label(root[m],text = i.upper(), font = ("Segoe Script", 20,"bold"))
	a.config(fg = "white", bg = "black")
	a.pack()
	root[m].title(i.upper())
	cv.pack()
	s = turtle.TurtleScreen(cv)
	s.bgcolor("white")
	t = turtle.RawTurtle(s)
	t.pensize(2)
	#t.speed(1)
	t.color("black", (1, 0.85, 0.85))
	t.penup()
	t.setx(-init_x)
	t.sety(init_y)
	t.pendown()
	t.forward(int(d[1]))
	t.right(90)
	t.forward(int(d[0]))
	t.right(90)
	t.forward(int(d[1]))
	t.right(90)
	t.forward(int(d[0]))
	print("i",i)
	for j in D[i]:
		#print("j",j)
		#print(t.position())
		t.color("black")
		if j != "Stair case":
			t.penup()
			t.right(90)
			t.sety(init_y - D[i][j]['top'])
			#print(t.position())
			t.setx(D[i][j]['left']-init_x)
			t.pendown()
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			t.right(90)
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			st_pos = t.position()
			t.penup()
			t.setx(D[i][j]['left'] - init_x +  D[i][j]['width']/2)
			t.sety(init_y - D[i][j]['top'] - D[i][j]['length']/2)
			t.color("blue")
			t.write(j.upper(), True, align = "center", font=("Segoe Script", 10, "italic"))
			t.setx(st_pos[0])
			t.sety(st_pos[1])
			t.pendown()
			st_pos = t.position()
			t.penup()
			if j == "Entrance":
				print("before",t.towards(0,0))
				draw_door(t,D[i][j])
				t.color("blue")
				t.penup()
				t.setx(st_pos[0])
				t.sety(st_pos[1])
				print("after",t.towards(0,0))
				t.pendown()
				t.left(90)
		else:
			st_pos = t.position()
			steps = D[i][j]['length']/8
			t.penup()
			t.sety(init_y - D[i][j]['top'])
			t.setx(D[i][j]['left']-init_x)
			t.pendown()
			t.color("grey")
			for k in range(8):
				t.right(90)
				t.forward(D[i][j]["width"])
				t.right(90)
				t.forward(steps)
				t.right(90)
				t.forward(D[i][j]["width"])
				t.right(90)
				t.forward(steps)
				t.backward(steps)
			st_pos = t.position()
			t.penup()
			t.setx(D[i][j]["left"] + D[i][j]["width"]/2 - init_x)
			t.sety(init_y - D[i][j]["top"] - D[i][j]["length"]/2)
			t.color("blue")
			t.write(j.upper(), True, align = "center", font=("Segoe Script", 10, "italic"))
			t.setx(st_pos[0])
			t.sety(st_pos[1])
			t.pendown()
			t.penup()
			t.forward(D[i][j]["length"])
			t.pendown()
		write_dim(t,D[i][j])
m = 0
for i in D:
	init_x = int(d[1])/2
	init_y = int(d[0])/2
	flag = False
	l = []
	flag, l = check(flag, init_x,init_y,D[i], l)
	print(flag)
	if not flag:
		print("hi")
		draw_plan(m, init_x,init_y)
		m = m+1
	else:
		a = tkinter.Tk()
		l = tkinter.Message(a,text = str(i.upper())+" cannot be drawn because there is a dimension problem in ".upper()+str(l), aspect=400, font=("Segoe Script", 12, "italic"))
		l.config(bg = "black", fg = "white")
		l.pack(expand = tkinter.YES, fill = tkinter.BOTH)
		#print(i,"cannot be drawn because there is a dimension problem in",l)
tkinter.mainloop()