from tur import*

#file reading
f = open("file1.txt","r")
f = f.readlines() # reading file into a variable
dim = f[0].split(":")[1] # stores the site dimension
D = {} # Dictionary containing site plan

# strips next line in all the lines
for i in range(0,len(f)):
	f[i] = f[i].strip()

# to create a dictionary of site plan
for i in range(1,len(f)):
	global floor
	global rooms
	if f[i].find("-") < 0 and len(f[i]) > 0:# if it is not "--------" and empty line
		if f[i].find(",") < 0: # it is the floor/partition
			if flag == True: # it is a floor
				floor = f[i].strip()
				D[floor] = {}
			else: # it is a room
				rooms = f[i].strip()
				D[floor][rooms] = {}
		else: # it is the dimensions of the room
			f[i].strip()
			l = f[i].split(",")
			for j in l:
				a = j.split(":")
				D[floor][rooms][a[0]] = a[1]
		flag = False		
	elif len(f[i]) != 0:# if "---------------" is found then next line is the floor
		flag = True	

print(D)

draw(D)
