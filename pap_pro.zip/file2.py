#file reading
import turtle
f = open("file1.txt","r")
f = f.readlines() # reading file into a variable
dim = f[0].split(":")[1] # stores the site dimension
D = {} # Dictionary containing site plan

# strips next line in all the lines
for i in range(0,len(f)):
	f[i] = f[i].strip()

# to create a dictionary of site plan
for i in range(1,len(f)):
	global floor
	global rooms
	if f[i].find("-") < 0 and len(f[i]) > 0:# if it is not "--------" and empty line
		if f[i].find(",") < 0: # it is the floor/partition
			if flag == True: # it is a floor
				floor = f[i].strip()
				D[floor] = {}
			else: # it is a room
				rooms = f[i].strip()
				D[floor][rooms] = {}
		else: # it is the dimensions of the room
			f[i].strip()
			l = f[i].split(",")
			for j in l:
				a = j.split(":")
				D[floor][rooms][a[0].strip()] = int(a[1])
		flag = False		
	elif len(f[i]) != 0:# if "---------------" is found then next line is the floor
		flag = True	

print(D)
t = turtle.Turtle()
t.color("red", "green")
t.penup()
t.setx(-650)
t.sety(300)
t.pendown()
d = dim.split("*")
t.forward(int(d[1]))
t.right(90)
t.forward(int(d[0]))
t.right(90)
t.forward(int(d[1]))
t.right(90)
t.forward(int(d[0]))
for i in D:
	if i == "ground floor":
		print("i",i)
		for j in D[i]:
			print("j",j)
			print(t.position())
			t.penup()
			t.right(90)
			t.sety(300 - D[i][j]['top'])
			print(t.position())
			t.showturtle()
			t.setx(D[i][j]['left']-650)
			t.pendown()
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			t.right(90)
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			st_pos = t.position()
			t.penup()
			t.setx(D[i][j]['left'] - 650 +  D[i][j]['width'] - 4*len(j))
			t.sety(300 - D[i][j]['top'] - D[i][j]['length']/2)
			t.pendown()
			t.color("blue")
			t.write(j, True, align = "center")
			t.color("red", "green")
			t.penup()
			t.setx(st_pos[0])
			t.sety(st_pos[1])
			t.pendown()
turtle.mainloop()