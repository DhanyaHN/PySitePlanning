f = open("file1.txt","r")
l = f.readline().strip()
print(l)
D = {}
dim = l.split(":")[1]
print(dim)
i = 0
while i in f:
	print(i)
	if i.find("-") < 0 and len(i) > 0:
		if i.find(",") < 0:
			part = i.strip()
			D[l[0]][part] = {}
			print(D)
		else:
			prop = i.split(",")
			for j in prop:
				a = j.split(":")
				D[l[0]][part][a[0]] = a[1]
	else:
		l = f.readline().strip()
		D[l[0]] = {}	
print(D)