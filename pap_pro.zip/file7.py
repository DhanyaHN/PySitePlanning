#file reading
import turtle, tkinter

f = open("file1.txt","r")
f = f.readlines() # reading file into a variable
dim = f[0].split(":")[1] # stores the site dimension
D = {} # Dictionary containing site plan

# strips next line in all the lines
for i in range(0,len(f)):
	f[i] = f[i].strip()

# to create a dictionary of site plan
for i in range(1,len(f)):
	global floor
	global rooms
	if f[i].find("-") < 0 and len(f[i]) > 0:# if it is not "--------" and empty line
		if f[i].find(",") < 0: # it is the floor/partition
			if flag == True: # it is a floor
				floor = f[i].strip()
				D[floor] = {}
			else: # it is a room
				rooms = f[i].strip()
				D[floor][rooms] = {}
		else: # it is the dimensions of the room
			f[i].strip()
			l = f[i].split(",")
			for j in l:
				a = j.split(":")
				D[floor][rooms][a[0].strip()] = int(a[1])
		flag = False		
	elif len(f[i]) != 0:# if "---------------" is found then next line is the floor
		flag = True	

#print(D)
root = []
d = dim.split("*")
def check(flag, init_x, init_y, rooms, l):
	checked = []
	for i in rooms:
		for j in rooms:
			if i != j and (((i,j) and (j,i)) not in checked):
				x1 = (rooms[i]["left"] - init_x, rooms[i]["left"]+rooms[i]["width"] - init_x)
				y1 = (init_y - rooms[i]["top"], init_y - rooms[i]["top"] - rooms[i]["length"])
				x2 = (rooms[j]["left"] - init_x, rooms[j]["left"] + rooms[j]["width"] - init_x)
				y2 = (init_y - rooms[j]["top"],init_y - rooms[j]["top"] - rooms[j]["length"])
				#print(i,": x1,y1",x1,y1)
				#print(j,": x2,y2",x2,y2)
				#print()
				if x1[0] < x1[1]:
					a = x1[0]
					b = x1[1]
				else:
					a = x1[1]
					b = x1[0]
				if y1[0] < y1[1]:
					c = y1[0]
					d = y1[1]
				else:
					c = y1[1]
					d = y1[0]
				if ((a < x2[0] < b) or (a < x2[1] < b)) and ((c < y2[0] < d) or (c < y2[1] < d)):
					print(i,j)
					l.append((i,j))
					flag = True
				checked.append((i,j))
	return flag, l
def draw_door(t,door_dim):
	t.setx(door_dim['left'] + door_dim["width"] - init_x)
	t.sety(init_y - door_dim["top"])
	t.right(180)
	t.color("brown")
	t.forward(door_dim["length"]/3)
	t.pendown()
	t.right(90)
	t.forward(door_dim["width"]/4)
	t.left(90)
	t.forward(door_dim["length"]/3)
	t.left(90)
	t.forward(door_dim["width"]/4)
def write_dim(t, dim):
	t.pensize(0)
	t.forward(2)

sc = turtle.Shape("compound")	
def draw_plan(part, m):
	root.append(tkinter.Tk())
	cv = tkinter.Canvas(root[m], width=int(d[1])+50,height=int(d[0])+50, bg="#FFFFFF")
	a = tkinter.Label(root[m],text = i.upper(), font = ("Segoe Script", 20,"bold"))
	a.config(fg = "white", bg = "black")
	a.pack()
	root[m].title(i.upper())
	cv.pack()
	s = turtle.TurtleScreen(cv)
	s.bgcolor(0.85, 0.85, 1)
	c1 = int(d[0])/2
	c2 = int(d[1])/2
	print(c1,c2)
	outline = ((-c1,-c2),(c1,-c2),(c1,c2),(-c1,c2))
	sc.addcomponent(outline, outline = "black", fill = "white")
	for j in D[i]:
		print(j,"c1,c2 : ", (c1,c2),"left: ", D[i][j]["left"],"top: ", D[i][j]["top"])
		p2 = - c1 + D[i][j]["left"]
		p1 = c2 - D[i][j]["top"]
		print(j,"p2",p2)
		if j != "Stair case":
			part.append(((p1,p2),(p1 + D[i][j]["width"] , p2 ),(p1 + D[i][j]["width"],p2 - D[i][j]["length"]),(p1, p2 - D[i][j]["length"])))
			#sc.addcomponent(part[m-1],"white","black")
			#print(j,part[m-1])
			#print()(p1, p2)
			#print(j, ((p1, p2),(p1 + D[i][j]["width"]),(p1 + D[i][j]["width"],p2),( p2 - D[i][j]["length"]),(p1, p2 - D[i][j]["length"])))
			#if j == "Entrance":
			#	draw_door(t,D[i][j])
		else:
			steps = D[i][j]['length']/8
			step = []
			for k in range(8):
				step.append(((-p1, p2 - k * steps),(p1,p2 - k * steps),(p1,-p2 - k *steps),(-p1,-p2 - k * steps)))
				sc.addcomponent(step[k],"white","black")
		#write_dim(D[i][j])
	print(part[0])
	sc.addcomponent(part[0],"white","black")
	print(part[1])
	sc.addcomponent(part[1],"white","black")
	turtle.register_shape("myshape",sc)
	turtle.shape("myshape")
m = 0
for i in D:
	flag = False
	l = []
	part = []
	flag, l = check(flag, int(d[0])/2, int(d[1])/2, D[i], l)
	print(flag)
	if not flag:
		draw_plan(part, m)
		m = m+1
	else:
		a = tkinter.Tk()
		l = tkinter.Message(a,text = str(i.upper())+" cannot be drawn because there is a dimension problem in ".upper(), aspect=400, font=("Segoe Script", 12, "italic"))
		l.config(bg = "black", fg = "white")
		l.pack(expand = tkinter.YES, fill = tkinter.BOTH)
		#print(i,"cannot be drawn because there is a dimension problem in",l)'''
turtle.mainloop()