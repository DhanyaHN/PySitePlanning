#file reading
import turtle, tkinter

f = open("file1.txt","r")
f = f.readlines() # reading file into a variable
dim = f[0].split(":")[1] # stores the site dimension
D = {} # Dictionary containing site plan

# strips next line in all the lines
for i in range(0,len(f)):
	f[i] = f[i].strip()

# to create a dictionary of site plan
for i in range(1,len(f)):
	global floor
	global rooms
	if f[i].find("-") < 0 and len(f[i]) > 0:# if it is not "--------" and empty line
		if f[i].find(",") < 0: # it is the floor/partition
			if flag == True: # it is a floor
				floor = f[i].strip()
				D[floor] = {}
			else: # it is a room
				rooms = f[i].strip()
				D[floor][rooms] = {}
		else: # it is the dimensions of the room
			f[i].strip()
			l = f[i].split(",")
			for j in l:
				a = j.split(":")
				D[floor][rooms][a[0].strip()] = int(a[1])
		flag = False		
	elif len(f[i]) != 0:# if "---------------" is found then next line is the floor
		flag = True	

print(D)
def draw_door(t,door_dim):
	t.setx(door_dim['left'] + door_dim["width"] - init_x)
	t.sety(init_y - door_dim["top"])
	t.right(180)
	t.color("brown")
	t.forward(door_dim["length"]/3)
	t.pendown()
	t.right(90)
	t.forward(door_dim["width"]/4)
	t.left(90)
	t.forward(door_dim["length"]/3)
	t.left(90)
	t.forward(door_dim["width"]/4)
root = []
#cv = []
#t = []
#s = []
#t.ht()
m = 0
d = dim.split("*")
for i in D:
	root.append(tkinter.Tk())
	cv = tkinter.Canvas(root[m], width=int(d[1])+50,height=int(d[0])+50, bg="#ddffff")
	cv.pack()
	s = turtle.TurtleScreen(cv)
	s.bgcolor(0.85, 0.85, 1)
	t = turtle.RawTurtle(s)
	t.pensize(2)
	#t.speed(0)
	t.color("black", (1, 0.85, 0.85))
	init_x = int(d[1])/2
	init_y = int(d[0])/2
	t.penup()
	t.setx(-init_x)
	t.sety(init_y)
	t.pendown()
	t.forward(int(d[1]))
	t.right(90)
	t.forward(int(d[0]))
	t.right(90)
	t.forward(int(d[1]))
	t.right(90)
	t.forward(int(d[0]))
	print("i",i)
	for j in D[i]:
		#print("j",j)
		#print(t.position())
		t.color("black")
		if j != "Stair case":
			t.penup()
			t.right(90)
			t.sety(init_y - D[i][j]['top'])
			#print(t.position())
			t.setx(D[i][j]['left']-init_x)
			t.pendown()
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			t.right(90)
			t.forward(D[i][j]['width'])
			t.right(90)
			t.forward(D[i][j]['length'])
			st_pos = t.position()
			t.penup()
			t.setx(D[i][j]['left'] - init_x +  D[i][j]['width']/2)
			t.sety(init_y - D[i][j]['top'] - D[i][j]['length']/2)
			t.color("blue")
			t.write(j, True, align = "center", font=("Arial", 10, "normal"))
			t.setx(st_pos[0])
			t.sety(st_pos[1])
			t.pendown()
			st_pos = t.position()
			t.penup()
			if j == "Entrance":
				print("before",t.towards(0,0))
				draw_door(t,D[i][j])
				t.color("black")
				t.penup()
				t.setx(st_pos[0])
				t.sety(st_pos[1])
				print("after",t.towards(0,0))
				t.pendown()
				t.left(90)
		else:
			st_pos = t.position()
			steps = D[i][j]['length']/8
			t.penup()
			t.sety(init_y - D[i][j]['top'])
			t.setx(D[i][j]['left']-init_x)
			t.pendown()
			t.color("grey")
			for k in range(8):
				t.right(90)
				t.forward(D[i][j]["width"])
				t.right(90)
				t.forward(steps)
				t.right(90)
				t.forward(D[i][j]["width"])
				t.right(90)
				t.forward(steps)
				t.backward(steps)
			st_pos = t.position()
			t.penup()
			t.setx(D[i][j]["left"] + D[i][j]["width"]/2 - init_x)
			t.sety(init_y - D[i][j]["top"] - D[i][j]["length"]/2)
			t.color("blue")
			t.write(j, True, align = "center", font=("Arial", 12, "normal"))
			t.setx(st_pos[0])
			t.sety(st_pos[1])
			t.pendown()
	m = m+1
tkinter.mainloop()