import sqlite3
db = sqlite3.connect("site_plan.sqlite3")
cur = db.cursor()
#print(showdatabase())

'''cur.executescript("""create table demo(ID INTEGER PRIMARY KEY NOT NULL UNIQUE,
	OWNER TEXT,
	DIMENSION TEXT,
	LOCATION TEXT,
	FILE TEXT);""")'''
print(cur.tables())


#print(cur.fetchall())